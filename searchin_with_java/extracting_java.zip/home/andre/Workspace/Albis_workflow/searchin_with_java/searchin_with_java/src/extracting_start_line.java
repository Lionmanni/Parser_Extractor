import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;


public class extracting_start_line {

    public static void main(String[] args) {
    // For demonstration purposes, we'll use a hardcoded file path.
    // In a real-world scenario, you might get this path from command line arguments or other sources.
    String filePath = "/home/andre/Workspace/WfJavaServer/source/com/albis/hitec/workflow/server/WorkflowServerFullInterface.java";
        try {
        String result = findCodeStart(filePath);
        System.out.println(result);
    } catch (IOException e) {
        System.err.println("Error reading the file: " + e.getMessage());
    }
}

    public static String findCodeStart(String filePath) throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            int lineNumber = 0;

            boolean inBlockComment = false;

            while ((line = reader.readLine()) != null) {
                lineNumber++;

                // Check for block comments
                if (line.trim().startsWith("/*")) {
                    inBlockComment = true;
                }
                if (inBlockComment && line.trim().endsWith("*/")) {
                    inBlockComment = false;
                    continue;
                }
                if (inBlockComment) {
                    continue;
                }

                // Check for single-line comments, package declarations, and imports
                if (line.trim().startsWith("//") ||
                        line.trim().startsWith("package") ||
                        line.trim().startsWith("import")) {
                    continue;
                }

                // If we reach here, we're likely at the start of the actual code
                return "Code starts at line " + lineNumber;
            }
        }

        return "Couldn't determine the start of the code.";
    }
}
